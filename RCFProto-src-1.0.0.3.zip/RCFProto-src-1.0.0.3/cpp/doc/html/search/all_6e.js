var searchData=
[
  ['notifyoncancel',['NotifyOnCancel',['../class_r_c_f_1_1_rcf_proto_controller.html#a81cd8c77e56078f00163ae115ba07731',1,'RCF::RcfProtoController::NotifyOnCancel()'],['../class_r_c_f_1_1_rcf_proto_session.html#a1562451866518cd986430d7362bbeca7',1,'RCF::RcfProtoSession::NotifyOnCancel()']]]
];
