var searchData=
[
  ['transportprotocol',['TransportProtocol',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a5ea60453bbbb813703659c927c050acd',1,'DeltaVSoft::RCFProto']]],
  ['transporttype',['TransportType',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a0774d401b79cd658ca48b449a360ed1f',1,'DeltaVSoft::RCFProto']]]
];
