var searchData=
[
  ['win32certificatelocation',['Win32CertificateLocation',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a7c8a1f4e48b20dcddd5aaf6e956d2bb6',1,'DeltaVSoft::RCFProto']]],
  ['win32certificatestore',['Win32CertificateStore',['../namespace_delta_v_soft_1_1_r_c_f_proto.html#a8b8e5f8eaa66f6ef0887aea921dfab7c',1,'DeltaVSoft::RCFProto']]]
];
