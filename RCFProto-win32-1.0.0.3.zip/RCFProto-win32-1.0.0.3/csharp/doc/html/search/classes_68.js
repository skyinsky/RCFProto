var searchData=
[
  ['httpendpoint',['HttpEndpoint',['../class_delta_v_soft_1_1_r_c_f_proto_1_1_http_endpoint.html',1,'DeltaVSoft::RCFProto']]],
  ['httpsendpoint',['HttpsEndpoint',['../class_delta_v_soft_1_1_r_c_f_proto_1_1_https_endpoint.html',1,'DeltaVSoft::RCFProto']]]
];
