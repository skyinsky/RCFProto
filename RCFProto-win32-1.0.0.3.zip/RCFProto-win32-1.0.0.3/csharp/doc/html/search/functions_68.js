var searchData=
[
  ['httpendpoint',['HttpEndpoint',['../class_delta_v_soft_1_1_r_c_f_proto_1_1_http_endpoint.html#a8ab3080da6979aabbd024d66275ae974',1,'DeltaVSoft.RCFProto.HttpEndpoint.HttpEndpoint(int port)'],['../class_delta_v_soft_1_1_r_c_f_proto_1_1_http_endpoint.html#ae5cdeabe971e74acd138140b1b73ead6',1,'DeltaVSoft.RCFProto.HttpEndpoint.HttpEndpoint(string ip, int port)']]],
  ['httpsendpoint',['HttpsEndpoint',['../class_delta_v_soft_1_1_r_c_f_proto_1_1_https_endpoint.html#af44ecb9db079f15d4a92f74cee072ddb',1,'DeltaVSoft.RCFProto.HttpsEndpoint.HttpsEndpoint(int port)'],['../class_delta_v_soft_1_1_r_c_f_proto_1_1_https_endpoint.html#ad25e5564bcc3774ec62208a0dcf86212',1,'DeltaVSoft.RCFProto.HttpsEndpoint.HttpsEndpoint(string ip, int port)']]]
];
