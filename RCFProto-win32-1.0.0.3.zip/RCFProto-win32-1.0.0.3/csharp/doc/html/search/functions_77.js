var searchData=
[
  ['win32namedpipeendpoint',['Win32NamedPipeEndpoint',['../class_delta_v_soft_1_1_r_c_f_proto_1_1_win32_named_pipe_endpoint.html#aa3f7014f38bd829a0e7e650205dd76a8',1,'DeltaVSoft::RCFProto::Win32NamedPipeEndpoint']]]
];
